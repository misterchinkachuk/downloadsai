import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface Balance {
  BTC: number;
  USDT: number;
  LTC: number;
  TRX: number;
}

interface Transaction {
  id: string;
  type: 'topup' | 'withdraw' | 'transfer';
  amount: number;
  coin: keyof Balance;
  status: 'waiting' | 'approved' | 'declined';
  timestamp: number;
  details?: any;
}

interface BalanceContextType {
  balance: Balance;
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id' | 'timestamp'>) => void;
  updateBalance: (coin: keyof Balance, amount: number) => void;
  getUSDBalance: () => number;
}

const BalanceContext = createContext<BalanceContextType | undefined>(undefined);

export const useBalance = () => {
  const context = useContext(BalanceContext);
  if (context === undefined) {
    throw new Error('useBalance must be used within a BalanceProvider');
  }
  return context;
};

// Mock USD prices for demonstration
const USD_PRICES: Balance = {
  BTC: 43000,
  USDT: 1,
  LTC: 75,
  TRX: 0.10
};

export const BalanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [balance, setBalance] = useState<Balance>({
    BTC: 0,
    USDT: 0,
    LTC: 0,
    TRX: 0
  });
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    if (user) {
      // Load user-specific balance and transactions
      const userBalance = localStorage.getItem(`fti_balance_${user.username}`);
      const userTransactions = localStorage.getItem(`fti_transactions_${user.username}`);
      
      if (userBalance) {
        setBalance(JSON.parse(userBalance));
      }
      
      if (userTransactions) {
        setTransactions(JSON.parse(userTransactions));
      }
    }
  }, [user]);

  const addTransaction = (transaction: Omit<Transaction, 'id' | 'timestamp'>) => {
    if (!user) return;
    
    const newTransaction: Transaction = {
      ...transaction,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now()
    };
    
    const updatedTransactions = [...transactions, newTransaction];
    setTransactions(updatedTransactions);
    localStorage.setItem(`fti_transactions_${user.username}`, JSON.stringify(updatedTransactions));
  };

  const updateBalance = (coin: keyof Balance, amount: number) => {
    if (!user) return;
    
    const newBalance = {
      ...balance,
      [coin]: Math.max(0, balance[coin] + amount)
    };
    
    setBalance(newBalance);
    localStorage.setItem(`fti_balance_${user.username}`, JSON.stringify(newBalance));
  };

  const getUSDBalance = (): number => {
    return Object.entries(balance).reduce((total, [coin, amount]) => {
      return total + (amount * USD_PRICES[coin as keyof Balance]);
    }, 0);
  };

  return (
    <BalanceContext.Provider value={{
      balance,
      transactions,
      addTransaction,
      updateBalance,
      getUSDBalance
    }}>
      {children}
    </BalanceContext.Provider>
  );
};