import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  username: string;
  name: string;
  surname: string;
  email: string;
  country: string;
  phone: string;
  isAdmin: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  register: (userData: Omit<User, 'isAdmin'> & { password: string }) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check for stored user data
    const storedUser = localStorage.getItem('fti_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (username: string, password: string): boolean => {
    // Admin login
    if (username === 'root' && password === 'Pirat2323/*-+') {
      const adminUser: User = {
        username: 'root',
        name: 'Administrator',
        surname: 'Admin',
        email: 'admin@ftiwallet.com',
        country: 'Global',
        phone: '+1234567890',
        isAdmin: true
      };
      setUser(adminUser);
      localStorage.setItem('fti_user', JSON.stringify(adminUser));
      return true;
    }

    // Regular user login - check localStorage for registered users
    const users = JSON.parse(localStorage.getItem('fti_users') || '[]');
    const foundUser = users.find((u: any) => u.username === username && u.password === password);
    
    if (foundUser) {
      const userWithoutPassword = { ...foundUser, isAdmin: false };
      delete userWithoutPassword.password;
      setUser(userWithoutPassword);
      localStorage.setItem('fti_user', JSON.stringify(userWithoutPassword));
      return true;
    }

    return false;
  };

  const register = (userData: Omit<User, 'isAdmin'> & { password: string }): boolean => {
    try {
      const users = JSON.parse(localStorage.getItem('fti_users') || '[]');
      
      // Check if username already exists
      if (users.find((u: any) => u.username === userData.username)) {
        return false;
      }

      users.push(userData);
      localStorage.setItem('fti_users', JSON.stringify(users));
      
      // Auto-login after registration
      const { password, ...userWithoutPassword } = userData;
      const newUser: User = { ...userWithoutPassword, isAdmin: false };
      setUser(newUser);
      localStorage.setItem('fti_user', JSON.stringify(newUser));
      
      return true;
    } catch {
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('fti_user');
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      register,
      logout,
      isAuthenticated: !!user
    }}>
      {children}
    </AuthContext.Provider>
  );
};