import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useBalance } from '@/contexts/BalanceContext';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft,
  Settings,
  User,
  LogOut,
  History,
  ShieldCheck
} from 'lucide-react';
import AppLayout from '@/components/AppLayout';

// Mock crypto prices with animation
const CRYPTO_PRICES = [
  { symbol: 'BTC', name: 'Bitcoin', price: 43250.75, change: 2.45, color: 'bitcoin' },
  { symbol: 'ETH', name: 'Ethereum', price: 2680.90, change: -1.23, color: 'ethereum' },
  { symbol: 'USDT', name: 'Tether', price: 1.00, change: 0.02, color: 'tether' },
  { symbol: 'LTC', name: 'Litecoin', price: 75.45, change: 3.12, color: 'litecoin' },
  { symbol: 'TRX', name: 'TRON', price: 0.105, change: -0.95, color: 'tron' },
];

const Dashboard = () => {
  const { user } = useAuth();
  const { balance, getUSDBalance } = useBalance();
  const [currentPriceIndex, setCurrentPriceIndex] = useState(0);

  // Animate through crypto prices
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPriceIndex((prev) => (prev + 1) % CRYPTO_PRICES.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const currentPrice = CRYPTO_PRICES[currentPriceIndex];
  const totalUSDValue = getUSDBalance();

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Animated Price Banner */}
        <Card className="bg-gradient-secondary border-border/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-primary font-bold text-xl">
                    {currentPrice.symbol}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground">
                    {currentPrice.name}
                  </h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl font-bold text-foreground">
                      ${currentPrice.price.toLocaleString()}
                    </span>
                    <Badge 
                      variant={currentPrice.change >= 0 ? "default" : "destructive"}
                      className={`${currentPrice.change >= 0 ? 'bg-success text-success-foreground' : 'bg-danger text-danger-foreground'}`}
                    >
                      {currentPrice.change >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                      {currentPrice.change > 0 ? '+' : ''}{currentPrice.change}%
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground">24h Volume</div>
                <div className="text-lg font-semibold">$2.4B</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Welcome Section */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              Welcome back, {user?.name}!
            </h1>
            <p className="text-muted-foreground">
              Manage your crypto portfolio
            </p>
          </div>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Total Portfolio Value</div>
            <div className="text-2xl font-bold text-primary">
              ${totalUSDValue.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button 
            asChild 
            className="h-20 bg-gradient-success hover:opacity-90 text-success-foreground"
          >
            <Link to="/topup" className="flex items-center justify-center space-x-3">
              <ArrowDownLeft className="w-6 h-6" />
              <span className="text-lg font-semibold">Top Up</span>
            </Link>
          </Button>
          
          <Button 
            asChild 
            className="h-20 bg-gradient-danger hover:opacity-90 text-danger-foreground"
          >
            <Link to="/withdraw" className="flex items-center justify-center space-x-3">
              <ArrowUpRight className="w-6 h-6" />
              <span className="text-lg font-semibold">Withdraw</span>
            </Link>
          </Button>
        </div>

        {/* Balance Overview */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Wallet className="w-5 h-5" />
              <span>Your Balance</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(balance).map(([coin, amount]) => (
                <div key={coin} className="text-center p-4 rounded-lg bg-muted/50">
                  <div className="text-2xl font-bold text-primary mb-1">
                    {amount.toFixed(6)}
                  </div>
                  <div className="text-sm text-muted-foreground font-medium">
                    {coin}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    ~${(amount * (CRYPTO_PRICES.find(p => p.symbol === coin)?.price || 1)).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default Dashboard;