import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import cryptoBg from '@/assets/crypto-bg.jpg';
import ftiLogo from '@/assets/fti-logo.png';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Simulate email sending (in real app, this would connect to backend)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Check if email exists in registered users
      const users = JSON.parse(localStorage.getItem('fti_users') || '[]');
      const user = users.find((u: any) => u.email === email);
      
      if (user) {
        toast({
          title: "Password Recovery Email Sent",
          description: `Password recovery instructions have been sent to ${email}`,
        });
        setSent(true);
      } else {
        toast({
          title: "Email Not Found",
          description: "No account found with this email address",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while sending the recovery email",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 relative"
      style={{
        backgroundImage: `url(${cryptoBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      
      <Card className="w-full max-w-md relative z-10 shadow-card border-border/50 bg-card/95 backdrop-blur">
        <CardHeader className="space-y-4 text-center">
          <div className="flex justify-center">
            <img src={ftiLogo} alt="FTI Wallet" className="w-16 h-16" />
          </div>
          <CardTitle className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Forgot Password
          </CardTitle>
          <p className="text-muted-foreground">
            {sent ? "Check your email" : "Enter your email to recover your password"}
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {!sent ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-input border-border focus:ring-primary"
                />
              </div>
              
              <Button
                type="submit"
                className="w-full bg-gradient-primary hover:opacity-90 text-primary-foreground font-semibold py-3"
                disabled={loading}
              >
                {loading ? "Sending..." : "Send Recovery Email"}
              </Button>
            </form>
          ) : (
            <div className="text-center space-y-4">
              <div className="text-success text-4xl">✓</div>
              <p className="text-foreground">
                We've sent password recovery instructions to your email address. Please check your inbox and follow the instructions to reset your password.
              </p>
              <Button
                className="w-full bg-gradient-primary hover:opacity-90 text-primary-foreground font-semibold py-3"
                onClick={() => setSent(false)}
              >
                Send Another Email
              </Button>
            </div>
          )}
          
          <div className="text-center space-y-2">
            <Link 
              to="/" 
              className="text-sm text-muted-foreground hover:text-primary transition-colors block"
            >
              Back to Login
            </Link>
            <Link 
              to="/register" 
              className="text-sm text-muted-foreground hover:text-primary transition-colors block"
            >
              Don't have an account? Register
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ForgotPasswordPage;