import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useBalance } from '@/contexts/BalanceContext';
import { History, ArrowUpRight, ArrowDownLeft, ArrowRightLeft } from 'lucide-react';
import AppLayout from '@/components/AppLayout';

const TransactionsPage = () => {
  const { transactions } = useBalance();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-success text-success-foreground';
      case 'waiting':
        return 'bg-warning text-warning-foreground';
      case 'declined':
        return 'bg-danger text-danger-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'topup':
        return <ArrowDownLeft className="w-4 h-4" />;
      case 'withdraw':
        return <ArrowUpRight className="w-4 h-4" />;
      case 'transfer':
        return <ArrowRightLeft className="w-4 h-4" />;
      default:
        return <History className="w-4 h-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'topup':
        return 'Top Up';
      case 'withdraw':
        return 'Withdrawal';
      case 'transfer':
        return 'Transfer';
      default:
        return 'Transaction';
    }
  };

  const sortedTransactions = [...transactions].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center space-x-3">
          <History className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold text-foreground">Transactions</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
          </CardHeader>
          <CardContent>
            {sortedTransactions.length === 0 ? (
              <div className="text-center py-12">
                <History className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  No Transactions Yet
                </h3>
                <p className="text-muted-foreground">
                  Your transaction history will appear here
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {sortedTransactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                          {getTypeIcon(transaction.type)}
                        </div>
                        
                        <div>
                          <h3 className="font-semibold text-foreground">
                            {getTypeLabel(transaction.type)}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {transaction.amount} {transaction.coin}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(transaction.timestamp).toLocaleString()}
                          </p>
                          
                          {/* Additional details */}
                          {transaction.details?.toUsername && (
                            <p className="text-xs text-muted-foreground">
                              To: @{transaction.details.toUsername}
                            </p>
                          )}
                          {transaction.details?.walletAddress && (
                            <p className="text-xs text-muted-foreground">
                              To: {transaction.details.walletAddress.slice(0, 10)}...
                            </p>
                          )}
                          {transaction.details?.network && (
                            <p className="text-xs text-muted-foreground">
                              Network: {transaction.details.network}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <Badge className={getStatusColor(transaction.status)}>
                          {transaction.status.toUpperCase()}
                        </Badge>
                        
                        <div className="mt-2">
                          <span className={`text-lg font-semibold ${
                            transaction.type === 'topup' ? 'text-success' : 'text-danger'
                          }`}>
                            {transaction.type === 'topup' ? '+' : '-'}{transaction.amount}
                          </span>
                          <span className="text-sm text-muted-foreground ml-1">
                            {transaction.coin}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default TransactionsPage;