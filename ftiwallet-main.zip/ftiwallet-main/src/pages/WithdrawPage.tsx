import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useBalance } from '@/contexts/BalanceContext';
import { ArrowUpRight, CheckCircle } from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

const WithdrawPage = () => {
  const [amount, setAmount] = useState('');
  const [selectedCoin, setSelectedCoin] = useState('BTC');
  const [walletAddress, setWalletAddress] = useState('');
  const [selectedNetwork, setSelectedNetwork] = useState('');
  const [toUsername, setToUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [showApproval, setShowApproval] = useState(false);
  const [withdrawalType, setWithdrawalType] = useState<'external' | 'internal'>('external');
  const { balance, updateBalance, addTransaction } = useBalance();
  const { toast } = useToast();
  const navigate = useNavigate();

  const coins = ['BTC', 'USDT', 'LTC', 'TRX'];
  const networks = {
    BTC: ['Bitcoin (BTC)'],
    USDT: ['BNB (BEP20)', 'ETH (ERC20)', 'TRON (TRC20)'],
    LTC: ['Litecoin (LTC)'],
    TRX: ['TRON (TRC20)']
  };

  const handleExternalWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || !walletAddress || !selectedNetwork) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const withdrawAmount = parseFloat(amount);
    if (withdrawAmount <= 0 || withdrawAmount > balance[selectedCoin as keyof typeof balance]) {
      toast({
        title: "Error",
        description: "Invalid amount or insufficient balance",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Deduct balance temporarily (will be restored if declined)
      updateBalance(selectedCoin as keyof typeof balance, -withdrawAmount);
      
      // Add transaction
      addTransaction({
        type: 'withdraw',
        amount: withdrawAmount,
        coin: selectedCoin as keyof typeof balance,
        status: 'waiting',
        details: {
          walletAddress,
          network: selectedNetwork,
          type: 'external'
        }
      });
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      setShowApproval(true);
      
      toast({
        title: "Withdrawal Submitted",
        description: "Your withdrawal request has been sent for approval",
      });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process withdrawal",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInternalTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || !toUsername) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const transferAmount = parseFloat(amount);
    if (transferAmount <= 0 || transferAmount > balance[selectedCoin as keyof typeof balance]) {
      toast({
        title: "Error",
        description: "Invalid amount or insufficient balance",
        variant: "destructive",
      });
      return;
    }

    // Check if recipient exists
    const users = JSON.parse(localStorage.getItem('fti_users') || '[]');
    const recipient = users.find((u: any) => u.username === toUsername);
    
    if (!recipient) {
      toast({
        title: "Error",
        description: "User not found",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Transfer coins instantly
      updateBalance(selectedCoin as keyof typeof balance, -transferAmount);
      
      // Add to recipient's balance
      const recipientBalance = JSON.parse(localStorage.getItem(`fti_balance_${toUsername}`) || '{"BTC":0,"USDT":0,"LTC":0,"TRX":0}');
      recipientBalance[selectedCoin] += transferAmount;
      localStorage.setItem(`fti_balance_${toUsername}`, JSON.stringify(recipientBalance));
      
      // Add transaction
      addTransaction({
        type: 'transfer',
        amount: transferAmount,
        coin: selectedCoin as keyof typeof balance,
        status: 'approved',
        details: {
          toUsername,
          type: 'internal'
        }
      });
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Transfer Successful",
        description: `${transferAmount} ${selectedCoin} sent to @${toUsername}`,
      });
      
      navigate('/dashboard');
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process transfer",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (showApproval) {
    return (
      <AppLayout>
        <div className="max-w-md mx-auto">
          <Card className="text-center">
            <CardContent className="p-8 space-y-6">
              <div className="w-20 h-20 mx-auto bg-success/20 rounded-full flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-success" />
              </div>
              
              <div>
                <h2 className="text-2xl font-bold text-success mb-2">
                  Approved
                </h2>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  YOUR SENDING ON THE WAY
                </h3>
                <p className="text-muted-foreground">
                  Waiting approve of Administrator
                </p>
              </div>
              
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Withdrawal Details:</p>
                <p className="font-semibold">{amount} {selectedCoin}</p>
                <p className="text-sm text-muted-foreground">{walletAddress}</p>
              </div>
              
              <Button 
                onClick={() => navigate('/dashboard')}
                className="w-full"
              >
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-md mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <ArrowUpRight className="w-5 h-5" />
              <span>Withdraw</span>
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            <Tabs value={withdrawalType} onValueChange={(value) => setWithdrawalType(value as 'external' | 'internal')} className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="external">External Wallet</TabsTrigger>
                <TabsTrigger value="internal">To User</TabsTrigger>
              </TabsList>

              <TabsContent value="external" className="space-y-6">
                <form onSubmit={handleExternalWithdraw} className="space-y-6">
                  {/* Amount and Coin Selection */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount</Label>
                      <Input
                        id="amount"
                        type="number"
                        step="0.000001"
                        placeholder="0.000000"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        required
                      />
                      <p className="text-xs text-muted-foreground">
                        Available: {balance[selectedCoin as keyof typeof balance]} {selectedCoin}
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="coin">Select Coin</Label>
                      <Select value={selectedCoin} onValueChange={setSelectedCoin}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {coins.map((coin) => (
                            <SelectItem key={coin} value={coin}>
                              {coin}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Wallet Address */}
                  <div className="space-y-2">
                    <Label htmlFor="walletAddress">Wallet Address</Label>
                    <Input
                      id="walletAddress"
                      type="text"
                      placeholder="Enter wallet address"
                      value={walletAddress}
                      onChange={(e) => setWalletAddress(e.target.value)}
                      required
                    />
                  </div>

                  {/* Network Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="network">Network</Label>
                    <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose network" />
                      </SelectTrigger>
                      <SelectContent>
                        {networks[selectedCoin as keyof typeof networks]?.map((network) => (
                          <SelectItem key={network} value={network}>
                            {network}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-danger hover:opacity-90 text-danger-foreground font-semibold py-3"
                    disabled={loading}
                  >
                    {loading ? "Processing..." : "SEND"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="internal" className="space-y-6">
                <form onSubmit={handleInternalTransfer} className="space-y-6">
                  {/* Amount and Coin Selection */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount</Label>
                      <Input
                        id="amount"
                        type="number"
                        step="0.000001"
                        placeholder="0.000000"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        required
                      />
                      <p className="text-xs text-muted-foreground">
                        Available: {balance[selectedCoin as keyof typeof balance]} {selectedCoin}
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="coin">Select Coin</Label>
                      <Select value={selectedCoin} onValueChange={setSelectedCoin}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {coins.map((coin) => (
                            <SelectItem key={coin} value={coin}>
                              {coin}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Username */}
                  <div className="space-y-2">
                    <Label htmlFor="toUsername">TO USERNAME:</Label>
                    <Input
                      id="toUsername"
                      type="text"
                      placeholder="Enter username"
                      value={toUsername}
                      onChange={(e) => setToUsername(e.target.value)}
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-primary hover:opacity-90 text-primary-foreground font-semibold py-3"
                    disabled={loading}
                  >
                    {loading ? "Processing..." : "SEND"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default WithdrawPage;