import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { ShieldCheck, Plus, Minus, Clock, CheckCircle, XCircle } from 'lucide-react';
import AppLayout from '@/components/AppLayout';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

const AdminPanel = () => {
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedCoin, setSelectedCoin] = useState('BTC');
  const [amount, setAmount] = useState('');
  const [operation, setOperation] = useState<'add' | 'remove'>('add');
  const { toast } = useToast();

  // Get registered users
  const users = JSON.parse(localStorage.getItem('fti_users') || '[]');
  const coins = ['BTC', 'USDT', 'LTC', 'TRX'];

  // Mock pending transactions for approval
  const [pendingTopUps, setPendingTopUps] = useState([
    {
      id: '1',
      username: 'john_doe',
      amount: 0.001,
      coin: 'BTC',
      cardNumber: '**** **** **** 1234',
      cardHolder: 'John Doe',
      timestamp: Date.now() - 300000,
    },
    {
      id: '2',
      username: 'jane_smith',
      amount: 100,
      coin: 'USDT',
      cardNumber: '**** **** **** 5678',
      cardHolder: 'Jane Smith',
      timestamp: Date.now() - 600000,
    }
  ]);

  const [pendingWithdrawals, setPendingWithdrawals] = useState([
    {
      id: '3',
      username: 'bob_wilson',
      amount: 0.5,
      coin: 'LTC',
      walletAddress: 'LTC1a2b3c4d5e6f7g8h9i0j',
      network: 'LTC',
      timestamp: Date.now() - 900000,
    }
  ]);

  const handleManageBalance = () => {
    if (!selectedUser || !amount || parseFloat(amount) <= 0) {
      toast({
        title: "Error",
        description: "Please fill in all fields with valid values",
        variant: "destructive",
      });
      return;
    }

    try {
      // Get user's current balance
      const userBalance = JSON.parse(localStorage.getItem(`fti_balance_${selectedUser}`) || '{"BTC":0,"USDT":0,"LTC":0,"TRX":0}');
      
      const changeAmount = parseFloat(amount);
      const finalAmount = operation === 'add' ? changeAmount : -changeAmount;
      
      userBalance[selectedCoin] = Math.max(0, userBalance[selectedCoin] + finalAmount);
      
      localStorage.setItem(`fti_balance_${selectedUser}`, JSON.stringify(userBalance));
      
      toast({
        title: "Balance Updated",
        description: `${operation === 'add' ? 'Added' : 'Removed'} ${amount} ${selectedCoin} ${operation === 'add' ? 'to' : 'from'} ${selectedUser}'s account`,
      });
      
      setAmount('');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update balance",
        variant: "destructive",
      });
    }
  };

  const handleApproveTopUp = (topUpId: string, approve: boolean) => {
    const topUp = pendingTopUps.find(t => t.id === topUpId);
    if (!topUp) return;

    if (approve) {
      // Add coins to user balance
      const userBalance = JSON.parse(localStorage.getItem(`fti_balance_${topUp.username}`) || '{"BTC":0,"USDT":0,"LTC":0,"TRX":0}');
      userBalance[topUp.coin] += topUp.amount;
      localStorage.setItem(`fti_balance_${topUp.username}`, JSON.stringify(userBalance));
    }

    setPendingTopUps(prev => prev.filter(t => t.id !== topUpId));
    
    toast({
      title: approve ? "Top-Up Approved" : "Top-Up Declined",
      description: `${topUp.username}'s top-up request has been ${approve ? 'approved' : 'declined'}`,
      variant: approve ? "default" : "destructive",
    });
  };

  const handleApproveWithdrawal = (withdrawalId: string, approve: boolean) => {
    const withdrawal = pendingWithdrawals.find(w => w.id === withdrawalId);
    if (!withdrawal) return;

    setPendingWithdrawals(prev => prev.filter(w => w.id !== withdrawalId));
    
    toast({
      title: approve ? "Withdrawal Approved" : "Withdrawal Declined",
      description: `${withdrawal.username}'s withdrawal request has been ${approve ? 'approved' : 'declined'}`,
      variant: approve ? "default" : "destructive",
    });
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center space-x-3">
          <ShieldCheck className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold text-foreground">Admin Panel</h1>
          <Badge variant="secondary">Administrator</Badge>
        </div>

        <Tabs defaultValue="manage-balance" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="manage-balance">Manage Balance</TabsTrigger>
            <TabsTrigger value="waiting-approve">
              Waiting Approve ({pendingTopUps.length + pendingWithdrawals.length})
            </TabsTrigger>
            <TabsTrigger value="user-sendings">User Sendings</TabsTrigger>
          </TabsList>

          <TabsContent value="manage-balance">
            <Card>
              <CardHeader>
                <CardTitle>Add/Remove Coins to Users</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="user-select">Select User</Label>
                    <Select value={selectedUser} onValueChange={setSelectedUser}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a user" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((user: any) => (
                          <SelectItem key={user.username} value={user.username}>
                            {user.name} {user.surname} (@{user.username})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="coin-select">Select Coin</Label>
                    <Select value={selectedCoin} onValueChange={setSelectedCoin}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {coins.map((coin) => (
                          <SelectItem key={coin} value={coin}>
                            {coin}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.000001"
                      placeholder="Enter amount"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Operation</Label>
                    <div className="flex space-x-2">
                      <Button
                        variant={operation === 'add' ? 'default' : 'outline'}
                        onClick={() => setOperation('add')}
                        className="flex-1"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add
                      </Button>
                      <Button
                        variant={operation === 'remove' ? 'default' : 'outline'}
                        onClick={() => setOperation('remove')}
                        className="flex-1"
                      >
                        <Minus className="w-4 h-4 mr-2" />
                        Remove
                      </Button>
                    </div>
                  </div>
                </div>

                <Button onClick={handleManageBalance} className="w-full">
                  {operation === 'add' ? 'Add' : 'Remove'} {selectedCoin} {operation === 'add' ? 'to' : 'from'} User
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="waiting-approve">
            <div className="space-y-6">
              {/* Pending Top-Ups */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="w-5 h-5" />
                    <span>Pending Top-Ups ({pendingTopUps.length})</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {pendingTopUps.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No pending top-up requests</p>
                  ) : (
                    <div className="space-y-4">
                      {pendingTopUps.map((topUp) => (
                        <div key={topUp.id} className="border border-border rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="font-semibold">@{topUp.username}</h3>
                              <p className="text-sm text-muted-foreground">
                                {topUp.amount} {topUp.coin} • {topUp.cardNumber}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                Card Holder: {topUp.cardHolder}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(topUp.timestamp).toLocaleString()}
                              </p>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                onClick={() => handleApproveTopUp(topUp.id, true)}
                                className="bg-success text-success-foreground hover:bg-success/90"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleApproveTopUp(topUp.id, false)}
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Decline
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Pending Withdrawals */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="w-5 h-5" />
                    <span>Pending Withdrawals ({pendingWithdrawals.length})</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {pendingWithdrawals.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No pending withdrawal requests</p>
                  ) : (
                    <div className="space-y-4">
                      {pendingWithdrawals.map((withdrawal) => (
                        <div key={withdrawal.id} className="border border-border rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="font-semibold">@{withdrawal.username}</h3>
                              <p className="text-sm text-muted-foreground">
                                {withdrawal.amount} {withdrawal.coin} • {withdrawal.network}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                To: {withdrawal.walletAddress}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(withdrawal.timestamp).toLocaleString()}
                              </p>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                onClick={() => handleApproveWithdrawal(withdrawal.id, true)}
                                className="bg-success text-success-foreground hover:bg-success/90"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleApproveWithdrawal(withdrawal.id, false)}
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Decline
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="user-sendings">
            <Card>
              <CardHeader>
                <CardTitle>User Sendings History</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center py-8">
                  No user sendings to display
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default AdminPanel;