
package com.xxx.zzz.aall.okhttp3ll;

import com.xxx.zzz.aall.okioss.ByteStringzaq;

public abstract class WebSocketListenerzaq {
  
  public void onOpen(WebSocketzqa webSocket, Responseza response) {
  }

  
  public void onMessage(WebSocketzqa webSocket, String text) {
  }

  
  public void onMessage(WebSocketzqa webSocket, ByteStringzaq bytes) {
  }

  
  public void onClosing(WebSocketzqa webSocket, int code, String reason) {
  }

  
  public void onClosed(WebSocketzqa webSocket, int code, String reason) {
  }

  
  public void onFailure(WebSocketzqa webSocket, Throwable t, Responseza response) {
  }
}
