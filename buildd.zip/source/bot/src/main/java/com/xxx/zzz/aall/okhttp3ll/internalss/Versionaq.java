
package com.xxx.zzz.aall.okhttp3ll.internalss;

public final class Versionaq {
  public static String userAgent() {
    return "okhttp/3.8.1";
  }

  private Versionaq() {
  }
}
