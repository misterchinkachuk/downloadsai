

package com.xxx.zzz.aall.gsonllll.googlepp;

import com.xxx.zzz.aall.gsonllll.googlepp.streamss.JsonReaderq;

import java.io.IOException;


public interface ToNumberStrategyq {

  
  public Number readNumber(JsonReaderq in) throws IOException;
}
